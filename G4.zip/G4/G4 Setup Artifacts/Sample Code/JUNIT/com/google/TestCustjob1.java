package com.google;

import org.junit.jupiter.api.Test;

import com.google.g4.jruntime.jcl.job.executor.JclJobContext;
import com.google.g4.jruntime.jcl.job.executor.JclJobExecutor;
import com.google.job.Custjob1;
import com.google.util.JCLJobTestSupport;

import nl.cornerstone.programstructure.cobol.Module;

/**
 * 
 * @author G4 converter
 * 
 *
 * 
 */


public class TestCustjob1 extends Module {

	static JCLJobTestSupport jobTestSupport = new JCLJobTestSupport();
	JclJobExecutor jclJobExecutor;

	@nl.cornerstone.annotations.ASCII
	@Test
	public void test1() throws Exception {

		jobTestSupport.createDataDirectory();
		//jobTestSupport.copyDataFileFromResource(TestCustjob1.class, STEP1, STEP1);

		JclJobContext jclJobContext = jobTestSupport.createJclJobContext("Custjob1");
		jclJobExecutor = new JclJobExecutor(jclJobContext);

		Custjob1 custjob1 = new Custjob1(jclJobExecutor);

		Thread th = new Thread(custjob1);
		th.run();

	}
}