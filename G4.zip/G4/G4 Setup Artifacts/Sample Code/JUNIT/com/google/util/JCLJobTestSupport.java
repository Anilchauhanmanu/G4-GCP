package com.google.util;


import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.g4.jruntime.env.catalog.AuxiliaryLibrary;
import com.google.g4.jruntime.env.catalog.SimpleCatalog;
import com.google.g4.jruntime.jcl.job.executor.JclJobClassResolver;
import com.google.g4.jruntime.jcl.job.executor.JclJobContext;
import com.google.g4.jruntime.jcl.job.executor.MethodImporterProviderCreator;
import com.google.g4.jruntime.jcl.job.main.AuxiliaryLibraryNames;
import com.google.g4.jruntime.jcl.job.main.CompositeVariableResolver;
import com.google.g4.jruntime.jcl.job.manual.HsqldbConnector;

import nl.cornerstone.exception.JobConfigError;
import nl.cornerstone.extensionpoints.indexed.DatasetDbTransactionalConnection;
import nl.cornerstone.programstructure.ConfigurationResolver;
import nl.cornerstone.programstructure.PropertiesResolver;
import nl.cornerstone.sql.DbConnector;
import nl.cornerstone.sql.DbConnectors;

public class JCLJobTestSupport {

	private static final Logger log = LoggerFactory.getLogger(JCLJobTestSupport.class);

	public static final String[] JOB_PACKAGES = { "com.google.cloud.g4.job" };
	public static final String[] CODE_UNIT_PACKAGES = { "com.google.cloud.g4.includes",
			"com.google.cloud.g4.interfaces" };
	public static final String[] CODE_UNIT_PROTOTYPE_PACKAGES = { "com.google.cloud.g4" };
	public static final String[] ENTITY_INDEXED_PACKAGES = { "com.google.cloud.g4.includes" };

	public static final AuxiliaryLibraryNames auxiliaryLibraryNames = new AuxiliaryLibraryNames("TEST.LIB.AUX");

	public static final String DATA_DIRECTORY = "target/jcl-tmp/data";
	public static final String CONFIG_DIRECTORY = "target/jcl-tmp/config";
	public static final String LIBAUX_DIRECTORY = "target/jcl-tmp/libaux";
	public static final String BATCH_CONFIG_AUX_DIRECTORY = "batch/config/libaux";

	private Path rootPath = Paths.get(DATA_DIRECTORY);
	private Path configRootPath = Paths.get(CONFIG_DIRECTORY);
	private Path libAuxPath = Paths.get(LIBAUX_DIRECTORY);
	private AuxiliaryLibrary auxiliaryLibrary;
	private Path archivePath;
	private ConfigurationResolver jclVariableResolver;
	private ConfigurationResolver configurationResolver;
	private Properties jclVariables = new Properties();
	private Properties properties = new Properties();

	/**
	 * Create test data and config directory.
	 */
	public void createDataDirectory() {
		createDataDirectory(CONFIG_DIRECTORY, LIBAUX_DIRECTORY);
	}

	/**
	 * Create test data and config directory.
	 * 
	 * @param auxiliaryLibraryNames Names of auxiliary libraries.
	 */
	public void createDataDirectory(AuxiliaryLibraryNames auxiliaryLibraryNames) {
		createDataDirectory(CONFIG_DIRECTORY, LIBAUX_DIRECTORY, auxiliaryLibraryNames);
	}

	/**
	 * Create test data directory and re-use config directory.
	 *
	 * @param configDirectory Directory for configuration file, is different for
	 *                        every job.
	 */
	public void createDataDirectory(String configDirectory) {
		createDataDirectory(configDirectory, BATCH_CONFIG_AUX_DIRECTORY);
	}

	/**
	 * Create test data directory and re-use config directory.
	 *
	 * @param configDirectory Directory for configuration file, is different for
	 *                        every job.
	 * @param libAuxDirectory Directory for global auxiliary library files.
	 */
	public void createDataDirectory(String configDirectory, String libAuxDirectory) {
		createDataDirectory(configDirectory, libAuxDirectory, new AuxiliaryLibraryNames());
	}

	/**
	 * Create test data directory and re-use config directory.
	 *
	 * @param configDirectory       Directory for configuration file, is different
	 *                              for every job.
	 * @param libAuxDirectory       Directory for global auxiliary library files.
	 * @param auxiliaryLibraryNames Names of auxiliary libraries.
	 */
	public void createDataDirectory(String configDirectory, String libAuxDirectory,
			AuxiliaryLibraryNames auxiliaryLibraryNames) {
		this.rootPath = Paths.get(DATA_DIRECTORY); // No cleanup to facilitate troubleshooting.
		File file = rootPath.toFile();
		if (!file.exists()) {
			file.mkdirs();
		}
		this.configRootPath = Paths.get(configDirectory);
		File templateDir = configRootPath.toFile();
		if (!templateDir.exists()) {
			templateDir.mkdirs();
		}
		this.libAuxPath = Paths.get(libAuxDirectory);
		File libAuxDir = libAuxPath.toFile();
		if (!libAuxDir.exists()) {
			libAuxDir.mkdirs();
		}
		this.auxiliaryLibrary = new AuxiliaryLibrary(libAuxPath,
				Arrays.asList(auxiliaryLibraryNames.getAuxiliaryLibraries()));
	}

	/**
	 * Create a new AuxiliaryLibrary with auxiliaryLibraryNames.
	 * 
	 * @param auxiliaryLibraryNames Names of auxiliary libraries.
	 */
	public void setAuxiliaryLibrary(AuxiliaryLibraryNames auxiliaryLibraryNames) {
		this.auxiliaryLibrary = new AuxiliaryLibrary(libAuxPath,
				Arrays.asList(auxiliaryLibraryNames.getAuxiliaryLibraries()));
	}

	/**
	 * Copy data from input file to local data file.
	 *
	 * @param inputFileName Input filename.
	 * @param fileName      Name of created file.
	 */
	public void copyDataFileFromFile(String inputFileName, String fileName) {
		File root = rootPath.toFile();
		Path targetFilePath = Paths.get(root.getAbsolutePath(), fileName);
		try {
			Files.copy(Paths.get(inputFileName), targetFilePath, StandardCopyOption.REPLACE_EXISTING);
		} catch (Exception e) {
			throw new RuntimeException("Failed to read file " + inputFileName, e);
		}
	}

	// /**
	// * Copy data from resources to local data file.
	// *
	// * @param resourceName Resource name.
	// * @param fileName Name of created file.
	// */
	// public void copyDataFileFromResource(String resourceName, String fileName) {
//	    File root = rootPath.toFile();
//	    Path targetFilePath = Paths.get(root.getAbsolutePath(), fileName);
//	    try (InputStream inputStream = getResourceStream(ManualJob.class, resourceName)) {
//	      if (inputStream == null) {
//	        throw new RuntimeException("Failed to read resource " + resourceName);
//	      }
//	      Files.copy(inputStream, targetFilePath, StandardCopyOption.REPLACE_EXISTING);
//	    } catch (Exception e) {
//	      throw new RuntimeException("Failed to read resource " + resourceName, e);
//	    }
	// }

	/**
	 * Copy data from resources to local data file.
	 *
	 * @param baseClass    boseClass of the caller
	 * @param resourceName Resource name.
	 * @param fileName     Name of created file.
	 */
	public void copyDataFileFromResource(Class<?> baseClass, String resourceName, String fileName) {
		File root = rootPath.toFile();
		Path targetFilePath = Paths.get(root.getAbsolutePath(), fileName);
		try (InputStream inputStream = getResourceStream(baseClass, resourceName)) {
			if (inputStream == null) {
				throw new RuntimeException("Failed to read resource " + resourceName);
			}
			Files.copy(inputStream, targetFilePath, StandardCopyOption.REPLACE_EXISTING);
		} catch (Exception e) {
			throw new RuntimeException("Failed to read resource " + resourceName, e);
		}
	}

	/**
	 * Copy data from resources to local data file.
	 *
	 * @param baseClass    boseClass of the caller
	 * @param jobName      the job name
	 * @param resourceName Resource name.
	 * @param fileName     Name of created file.
	 */
	public void copyDataFileFromResource(Class<?> baseClass, String jobName, String resourceName, String fileName) {
		File root = rootPath.toFile();
		Path targetFilePath = Paths.get(root.getAbsolutePath(), fileName);
		try (InputStream inputStream = getResourceStream(baseClass, jobName + "/" + resourceName)) {
			if (inputStream == null) {
				throw new RuntimeException("Failed to read resource " + jobName + "/" + resourceName);
			}
			Files.copy(inputStream, targetFilePath, StandardCopyOption.REPLACE_EXISTING);
		} catch (Exception e) {
			throw new RuntimeException("Failed to read resource " + jobName + "/" + resourceName, e);
		}
	}

	/**
	 * Open input stream to resource file.
	 *
	 * @param baseClass    Base class.
	 * @param resourceName Name of resource.
	 * @return Input stream, null if not successful.
	 */
	private InputStream getResourceStream(Class<?> baseClass, String resourceName) {
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream(resourceName);
		if (inputStream == null) {
			inputStream = baseClass.getResourceAsStream(resourceName);
		}
		return inputStream;
	}

	/**
	 * @return JclJobContext for tests.
	 */
	public JclJobContext createJclJobContext(String jobName) {
		return createJclJobContext(jobName, createDbConnector(), configRootPath, libAuxPath);
	}

	/**
	 * @return JclJobContext for tests.
	 */
	public JclJobContext createJclJobContext(String jobName, DbConnector dbConnector) {
		return createJclJobContext(jobName, dbConnector, configRootPath, libAuxPath);
	}

	/**
	 * @return JclJobContext for tests.
	 */
	public JclJobContext createJclJobContext(String jobName, DbConnector dbConnector, Path configRootPath,
			Path libAuxPath) {
		DatasetDbTransactionalConnection idxConnector = null;
		if (dbConnector instanceof HsqldbConnector) {
			idxConnector = new DatasetDbTransactionalConnection(((HsqldbConnector) dbConnector).connection());
		}
		ConfigurationResolver jclVariableResolver = new PropertiesResolver(jclVariables);
		ConfigurationResolver configurationResolver = new PropertiesResolver(properties);
		JclJobClassResolver jclJobClassResolver = new JclJobClassResolver(JOB_PACKAGES, CODE_UNIT_PACKAGES,
				CODE_UNIT_PROTOTYPE_PACKAGES);
		return new JclJobContext(jobName, rootPath, configRootPath, auxiliaryLibrary, jclVariableResolver,
				configurationResolver, dbConnector, idxConnector, LocalDateTime.now(), jclJobClassResolver,
				new SimpleCatalog(rootPath), ENTITY_INDEXED_PACKAGES);
	}

	public JclJobContext createJclJobContext(String jobName, DbConnector dbConnector,
			DatasetDbTransactionalConnection idxConnector, Path configRootPath, Path libAuxPath) {
		ConfigurationResolver jclVariableResolver = new PropertiesResolver(jclVariables);
		ConfigurationResolver configurationResolver = new PropertiesResolver(properties);
		JclJobClassResolver jclJobClassResolver = new JclJobClassResolver(JOB_PACKAGES, CODE_UNIT_PACKAGES,
				CODE_UNIT_PROTOTYPE_PACKAGES);
		return new JclJobContext(jobName, rootPath, configRootPath, auxiliaryLibrary, jclVariableResolver,
				configurationResolver, dbConnector, idxConnector, LocalDateTime.now(), jclJobClassResolver,
				new SimpleCatalog(rootPath), ENTITY_INDEXED_PACKAGES);
	}

	/**
	 * @param dbConnector                   Database connector.
	 * @param configRootPath                Root path for configuration directory.
	 * @param libAuxPath                    Root path for auxiliary library
	 *                                      directory.
	 * @param overridingJclVariableResolver JCL variable resolver that overrides
	 *                                      standard predefined variables.
	 * @return JclJobContext for tests.
	 */
	public JclJobContext createJclJobContext(String jobName, DbConnector dbConnector, Path configRootPath,
			Path libAuxPath, ConfigurationResolver overridingJclVariableResolver) {
		CompositeVariableResolver jclVariableResolver = new CompositeVariableResolver();
		jclVariableResolver.addResolver(overridingJclVariableResolver);
		jclVariableResolver.addResolver(new PropertiesResolver(jclVariables));
		ConfigurationResolver configurationResolver = new PropertiesResolver(properties);
		JclJobClassResolver jclJobClassResolver = new JclJobClassResolver(JOB_PACKAGES, CODE_UNIT_PACKAGES,
				CODE_UNIT_PROTOTYPE_PACKAGES);
		return new JclJobContext(jobName, rootPath, configRootPath, libAuxPath, jclVariableResolver,
				configurationResolver, dbConnector, null, LocalDateTime.now(), jclJobClassResolver,
				ENTITY_INDEXED_PACKAGES);
	}

	/**
	 * @param dbConnector                   Database connector.
	 * @param idxConnector                  Database connector for index data sets.
	 * @param configRootPath                Root path for configuration directory.
	 * @param libAuxPath                    Root path for auxiliary library
	 *                                      directory.
	 * @param overridingJclVariableResolver JCL variable resolver that overrides
	 *                                      standard predefined variables.
	 * @return JclJobContext for tests.
	 */
	public JclJobContext createJclJobContext(String jobName, DbConnector dbConnector,
			DatasetDbTransactionalConnection idxConnector, Path configRootPath, Path libAuxPath,
			ConfigurationResolver overridingJclVariableResolver) {
		JclJobClassResolver jclJobClassResolver = new JclJobClassResolver(JOB_PACKAGES, CODE_UNIT_PACKAGES,
				CODE_UNIT_PROTOTYPE_PACKAGES);
		return createJclJobContext(jobName, dbConnector, idxConnector, configRootPath, libAuxPath,
				overridingJclVariableResolver, jclJobClassResolver);
	}

	/**
	 * @param dbConnector                   Database connector.
	 * @param idxConnector                  Database connector for index data sets.
	 * @param configRootPath                Root path for configuration directory.
	 * @param libAuxPath                    Root path for auxiliary library
	 *                                      directory.
	 * @param overridingJclVariableResolver JCL variable resolver that overrides
	 *                                      standard predefined variables.
	 * @return JclJobContext for tests.
	 */
	public JclJobContext createJclJobContext(String jobName, DbConnector dbConnector,
			DatasetDbTransactionalConnection idxConnector, Path configRootPath, Path libAuxPath,
			ConfigurationResolver overridingJclVariableResolver, JclJobClassResolver jclJobClassResolver) {
		CompositeVariableResolver jclVariableResolver = new CompositeVariableResolver();
		jclVariableResolver.addResolver(overridingJclVariableResolver);
		jclVariableResolver.addResolver(new PropertiesResolver(jclVariables));
		ConfigurationResolver configurationResolver = new PropertiesResolver(properties);
		return new JclJobContext(jobName, rootPath, configRootPath, libAuxPath, jclVariableResolver,
				configurationResolver, dbConnector, idxConnector, LocalDateTime.now(), jclJobClassResolver,
				ENTITY_INDEXED_PACKAGES);
	}

	/**
	 * @param jobName             Name of job (capitalized).
	 * @param dataDir             Directory with data files.
	 * @param configDir           Directory with JCL configuration files.
	 * @param libauxDir           Directory with auxiliary library files.
	 * @param jclVariableResolver Resolves JCL variables.
	 * @param configuration       Resolves configuration properties.
	 * @param dbConnector         Database connector.
	 * @param idxConnector        Database connection for indexed files (VSAM).
	 * @param scheduleDate        Schedule date.
	 * @return JCL job context.
	 */
	public static JclJobContext createJclJobContext(String jobName, Path dataDir, Path configDir, Path libauxDir,
			ConfigurationResolver jclVariableResolver, ConfigurationResolver configuration, DbConnector dbConnector,
			DatasetDbTransactionalConnection idxConnector, LocalDateTime scheduleDate) {
		JclJobClassResolver jclJobClassResolver = new JclJobClassResolver(JOB_PACKAGES, CODE_UNIT_PACKAGES,
				CODE_UNIT_PROTOTYPE_PACKAGES);
		return new JclJobContext(jobName, dataDir, configDir, libauxDir, jclVariableResolver, configuration,
				dbConnector, idxConnector, scheduleDate, jclJobClassResolver, ENTITY_INDEXED_PACKAGES);
	}

	/**
	 * @param jobName             Name of job (capitalized).
	 * @param dataDir             Directory with data files.
	 * @param configDir           Directory with JCL configuration files.
	 * @param libauxDir           Directory with auxiliary library files.
	 * @param jclVariableResolver Resolves JCL variables.
	 * @param configuration       Resolves configuration properties.
	 * @param dbConnector         Database connector.
	 * @param idxConnector        Database connection for indexed files (VSAM).
	 * @param scheduleDate        Schedule date.
	 * @return JCL job context.
	 */
	public static JclJobContext createJclJobContext(String jobName, Path dataDir, Path configDir, Path libauxDir,
			ConfigurationResolver jclVariableResolver, ConfigurationResolver configuration, DbConnector dbConnector,
			DatasetDbTransactionalConnection idxConnector, LocalDateTime scheduleDate,
			MethodImporterProviderCreator methodImporterProviderCreator) {
		JclJobClassResolver jclJobClassResolver = new JclJobClassResolver(JOB_PACKAGES, CODE_UNIT_PACKAGES,
				CODE_UNIT_PROTOTYPE_PACKAGES);
		return new JclJobContext(jobName, dataDir, configDir, libauxDir, jclVariableResolver, configuration,
				dbConnector, idxConnector, scheduleDate, jclJobClassResolver, ENTITY_INDEXED_PACKAGES);
	}

	/**
	 * Initialize DbConnector.
	 */
	public DbConnector createDbConnector() {
		DbConnector dbConnector = null;
		String databaseType = properties.getProperty("database.type", null);
		if (databaseType != null) {
			String url = properties.getProperty("database.url");
			String user = properties.getProperty("database.user");
			String password = properties.getProperty("database.password");
			if (url == null || user == null || password == null) {
				throw new JobConfigError(String.format("Invalid database configuration url=%s, user=%s, password=%s",
						url, user, password));
			} else {
				log.debug("Initialize database connection {}, {}, {}, {}", databaseType, url, user, password);
				if (databaseType.equals("HSQLDB")) {
					dbConnector = new DbConnectors.Hsqldb(url, user, password);
				} else if (databaseType.equals("TEST_HSQLDB")) {
					dbConnector = new HsqldbConnector(url, user, password);
				} else if (databaseType.equals("DB2")) {
					dbConnector = new DbConnectors.IbmDb2(url, user, password);
				} else {
					throw new JobConfigError("Unknown database.type configuration: " + databaseType);
				}
			}
		}
		return dbConnector;
	}

}
