package com.google;

import org.junit.jupiter.api.Test;

import com.google.g4.jruntime.jcl.job.executor.JclJobContext;
import com.google.g4.jruntime.jcl.job.executor.JclJobExecutor;
import com.google.job.Custjob3;
import com.google.util.JCLJobTestSupport;

import nl.cornerstone.programstructure.cobol.Module;

/**
 * 
 * @author G4 converter
 * 
 *
 * 
 */

public class TestCustjob3 extends Module {

	private static final String INPUT_DATA_FILE_NAME = "DEMO.PS.INPUT";
	private static final String INPUT_DATA_FILE_PATH = "data/DEMO.PS.INPUT";

	static JCLJobTestSupport jobTestSupport = new JCLJobTestSupport();
	JclJobExecutor jclJobExecutor;

	@nl.cornerstone.annotations.ASCII
	@Test
	public void test1() throws Exception {

		jobTestSupport.createDataDirectory();
		jobTestSupport.copyDataFileFromResource(TestCustjob3.class, INPUT_DATA_FILE_PATH, INPUT_DATA_FILE_NAME);

		JclJobContext jclJobContext = jobTestSupport.createJclJobContext("Custjob3");
		jclJobExecutor = new JclJobExecutor(jclJobContext);

		Custjob3 custjob3 = new Custjob3(jclJobExecutor);

		Thread th = new Thread(custjob3);
		th.run();

	}
}